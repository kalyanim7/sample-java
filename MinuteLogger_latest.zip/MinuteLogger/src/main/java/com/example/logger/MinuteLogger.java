
package com.example.logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Timer;
import java.util.TimerTask;

public class MinuteLogger {
    private static final Logger logger = LogManager.getLogger(MinuteLogger.class);

    public static void main(String[] args) {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                logger.info("Logging every 5 seconds: " + System.currentTimeMillis());
            }
        }, 0, 5000); // 5 seconds

        System.out.println("Logger started. Check logs/app.log for output.");
    }
}
